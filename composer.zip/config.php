<?php

    $gcaptcha_private = "6LfddL4UAAAAAOPEYcGmekOu4StWaAvdS1vlzCX4"

?>
